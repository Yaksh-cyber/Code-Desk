/**
 * server.js — ScorePulse Express API
 *
 * Routes:
 *   GET /api/health                        — server status
 *   GET /api/leagues                       — all leagues
 *   GET /api/matches?date=&league=&status= — matches with filters
 *   GET /api/matches/:id                   — single match detail
 *   GET /api/standings/:leagueCode         — league table
 *   GET /api/scorers/:leagueCode           — top scorers
 *   GET /api/live                          — all live matches right now
 *   POST /api/refresh/:type                — manually trigger a fetch
 */

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const compression = require('compression');
const cron       = require('node-cron');
const path       = require('path');

const { getDb, query }  = require('./db');
const fetcher            = require('./fetcher');

const app  = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(compression());
app.use(express.json());

// Serve the combined frontend from /public
app.use(express.static(path.join(__dirname, '../public')));

// ── Health ────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  const hasFD     = !!(process.env.FOOTBALL_DATA_TOKEN && process.env.FOOTBALL_DATA_TOKEN !== 'YOUR_FOOTBALL_DATA_TOKEN_HERE');
  const hasRapid  = !!(process.env.RAPIDAPI_KEY && process.env.RAPIDAPI_KEY !== 'YOUR_RAPIDAPI_KEY_HERE');
  const liveMatches = query(`SELECT COUNT(*) as cnt FROM matches WHERE status='live'`)[0]?.cnt || 0;
  const totalMatches = query(`SELECT COUNT(*) as cnt FROM matches`)[0]?.cnt || 0;

  res.json({
    status: 'ok',
    version: '1.0.0',
    time: new Date().toISOString(),
    apis: {
      footballData: hasFD ? 'connected' : 'not configured (using mock data)',
      apiFootball: hasRapid ? 'connected' : 'not configured (using mock data)',
    },
    data: { liveMatches, totalMatches }
  });
});

// ── Leagues ───────────────────────────────────────────────────
app.get('/api/leagues', (req, res) => {
  const leagues = query(`SELECT * FROM leagues ORDER BY name`);

  // Enrich with match counts
  const enriched = leagues.map(l => {
    const counts = query(`
      SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status='live' THEN 1 ELSE 0 END) as live,
        SUM(CASE WHEN status='scheduled' THEN 1 ELSE 0 END) as scheduled
      FROM matches WHERE league_id=?
    `, [l.id])[0] || { total:0, live:0, scheduled:0 };
    return { ...l, ...counts };
  });

  res.json({ leagues: enriched });
});

// ── Matches ───────────────────────────────────────────────────
app.get('/api/matches', (req, res) => {
  const { date, league, status } = req.query;

  let sql  = `SELECT * FROM matches WHERE 1=1`;
  const params = [];

  if (league && league !== 'all') {
    sql += ` AND league_id = ?`;
    params.push(league);
  }

  if (status && status !== 'all') {
    sql += ` AND status = ?`;
    params.push(status);
  }

  if (date) {
    // match_date is ISO string, filter by day
    sql += ` AND date(match_date) = date(?)`;
    params.push(date);
  }

  sql += ` ORDER BY
    CASE status WHEN 'live' THEN 0 WHEN 'scheduled' THEN 1 ELSE 2 END,
    match_date ASC`;

  const matches = query(sql, params);

  const formatted = matches.map(formatMatch);
  res.json({ matches: formatted, count: formatted.length });
});

// ── Single match detail ───────────────────────────────────────
app.get('/api/matches/:id', (req, res) => {
  const rows = query(`SELECT * FROM matches WHERE id = ?`, [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Match not found' });
  res.json({ match: formatMatch(rows[0]) });
});

// ── Standings ─────────────────────────────────────────────────
app.get('/api/standings/:leagueCode', async (req, res) => {
  const code = req.params.leagueCode.toUpperCase();

  // Attempt refresh if stale
  try {
    await fetcher.fetchStandings(code);
  } catch (e) {
    console.error('Standings fetch error:', e.message);
  }

  const rows = query(`
    SELECT * FROM standings WHERE league_id = ?
    ORDER BY position ASC
  `, [code]);

  if (!rows.length) {
    return res.status(404).json({ error: 'No standings for this league', leagueCode: code });
  }

  res.json({
    leagueCode: code,
    standings: rows.map(r => ({
      ...r,
      form: r.form ? r.form.split(',').filter(Boolean) : []
    }))
  });
});

// ── Top Scorers ───────────────────────────────────────────────
app.get('/api/scorers/:leagueCode', async (req, res) => {
  const code = req.params.leagueCode.toUpperCase();

  try {
    await fetcher.fetchTopScorers(code);
  } catch (e) {
    console.error('Scorers fetch error:', e.message);
  }

  const rows = query(`
    SELECT * FROM top_scorers WHERE league_id = ?
    ORDER BY rank ASC LIMIT 20
  `, [code]);

  res.json({ leagueCode: code, scorers: rows });
});

// ── Live matches ──────────────────────────────────────────────
app.get('/api/live', async (req, res) => {
  try {
    await fetcher.fetchLiveScores();
  } catch (e) {
    console.error('Live fetch error:', e.message);
  }

  const matches = query(`
    SELECT * FROM matches WHERE status = 'live'
    ORDER BY match_date ASC
  `);

  res.json({ matches: matches.map(formatMatch), count: matches.length });
});

// ── Manual refresh ────────────────────────────────────────────
app.post('/api/refresh/:type', async (req, res) => {
  const { type } = req.params;
  const { league } = req.query;

  try {
    if (type === 'live') {
      await fetcher.fetchLiveScores();
    } else if (type === 'standings' && league) {
      await fetcher.fetchStandings(league.toUpperCase());
    } else if (type === 'fixtures' && league) {
      await fetcher.fetchFixtures(league.toUpperCase());
    } else if (type === 'all') {
      for (const code of Object.keys(fetcher.LEAGUE_MAP)) {
        await fetcher.fetchStandings(code);
        await fetcher.fetchFixtures(code);
        await new Promise(r => setTimeout(r, 500));
      }
      await fetcher.fetchLiveScores();
    } else {
      return res.status(400).json({ error: 'Invalid type. Use: live, standings, fixtures, all' });
    }
    res.json({ ok: true, refreshed: type, league: league || 'all' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Helper: format match for API response ─────────────────────
function formatMatch(m) {
  let events = [], stats = {};
  try { events = JSON.parse(m.events_json || '[]'); } catch {}
  try { stats  = JSON.parse(m.stats_json  || '{}'); } catch {}

  // Format match time display
  let displayTime = m.minute;
  if (!displayTime && m.match_date) {
    try {
      const d = new Date(m.match_date);
      displayTime = d.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit', timeZone:'UTC' });
    } catch {}
  }

  return {
    id:        m.id,
    leagueId:  m.league_id,
    league:    m.league_name,
    status:    m.status,
    minute:    displayTime || m.minute || '',
    matchDate: m.match_date,
    round:     m.round || '',
    home: {
      id:    m.home_team_id,
      name:  m.home_team_name,
      logo:  m.home_team_logo,
      short: m.home_team_name?.split(' ').map(w=>w[0]).join('').slice(0,3) || ''
    },
    away: {
      id:    m.away_team_id,
      name:  m.away_team_name,
      logo:  m.away_team_logo,
      short: m.away_team_name?.split(' ').map(w=>w[0]).join('').slice(0,3) || ''
    },
    homeScore: m.home_score,
    awayScore: m.away_score,
    winner:    m.winner,
    events,
    stats
  };
}

// ── Scheduled cron jobs ───────────────────────────────────────
function startCrons() {
  // Live scores: every 30 seconds
  cron.schedule('*/30 * * * * *', async () => {
    try { await fetcher.fetchLiveScores(); } catch {}
  });

  // Fixtures + standings: every 5 minutes
  cron.schedule('*/5 * * * *', async () => {
    for (const code of Object.keys(fetcher.LEAGUE_MAP)) {
      try { await fetcher.fetchFixtures(code); } catch {}
      await new Promise(r => setTimeout(r, 700));
    }
  });

  // Standings + scorers: every hour
  cron.schedule('0 * * * *', async () => {
    for (const code of Object.keys(fetcher.LEAGUE_MAP)) {
      try { await fetcher.fetchStandings(code); } catch {}
      try { await fetcher.fetchTopScorers(code); } catch {}
      await new Promise(r => setTimeout(r, 700));
    }
  });

  console.log('⏰ Cron jobs started: live/30s, fixtures/5m, standings/1h');
}

// ── Fallthrough for SPA ───────────────────────────────────────
app.use((req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '../public/index.html'));
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

// ── Start ─────────────────────────────────────────────────────
async function start() {
  await getDb();
  await fetcher.bootstrap();
  startCrons();

  app.listen(PORT, () => {
    console.log(`\n🟢 ScorePulse API running at http://localhost:${PORT}`);
    console.log(`   Frontend: http://localhost:${PORT}`);
    console.log(`   Health:   http://localhost:${PORT}/api/health`);
    console.log(`   Matches:  http://localhost:${PORT}/api/matches`);
    console.log(`   Live:     http://localhost:${PORT}/api/live`);
    console.log(`   Standings:http://localhost:${PORT}/api/standings/PL\n`);
    console.log(`📌 To use real data, create a .env file from .env.example and add your API keys`);
    console.log(`   football-data.org: https://www.football-data.org/client/register (free)`);
    console.log(`   API-Football:      https://rapidapi.com/api-sports/api/api-football (free 100/day)\n`);
  });
}

start().catch(console.error);
