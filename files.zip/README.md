# 🟢 ScorePulse — Live Sports Scores

SofaScore-style website with Node.js backend, SQLite database, and real API integration.

---

## 🚀 Quick Start (Mock Data — works immediately)

```bash
cd scorepulse/backend
npm install
node server.js
```

Open **http://localhost:3001** — the site loads with realistic mock data immediately.

---

## ⚡ Get Real Live Data (Free API Keys)

### Step 1 — football-data.org (standings + fixtures)
1. Register free at **https://www.football-data.org/client/register**
2. Copy your API token from the dashboard

### Step 2 — API-Football on RapidAPI (live scores + top scorers)
1. Register free at **https://rapidapi.com/api-sports/api/api-football**
2. Subscribe to the **FREE** plan (100 requests/day)
3. Copy your RapidAPI key

### Step 3 — Create your .env file
```bash
cd scorepulse/backend
cp .env.example .env
# Edit .env and paste your keys:
```

```env
FOOTBALL_DATA_TOKEN=abc123yourtokenhere
RAPIDAPI_KEY=xyz456yourkeyhere
```

### Step 4 — Restart
```bash
node server.js
```

The **MOCK** badge in the top-right turns to **LIVE** when APIs are active.

---

## 📊 Database (SQLite)

The database file `scorepulse.db` is created automatically in the `backend/` folder.

### Schema

| Table | Contents |
|---|---|
| `leagues` | PL, UCL, La Liga, Bundesliga, Serie A, Ligue 1 |
| `teams` | Team info with logos |
| `matches` | All fixtures, live scores, events, stats |
| `standings` | Live league tables per season |
| `top_scorers` | Goal scorers per league |
| `cache_meta` | TTL tracking per API endpoint |

---

## 🔄 Data Refresh Schedule

| Data | Interval | Source |
|---|---|---|
| Live scores | Every 30 seconds | API-Football |
| Fixtures | Every 5 minutes | football-data.org |
| Standings | Every hour | football-data.org |
| Top scorers | Every hour | API-Football / football-data.org |

---

## 🛣️ API Endpoints

```
GET  /api/health                        — Server status + API connection info
GET  /api/leagues                       — All leagues with match counts
GET  /api/matches?date=&league=&status= — Filtered matches
GET  /api/matches/:id                   — Single match with events + stats
GET  /api/standings/:leagueCode         — League table (PL, CL, PD, BL1, SA, FL1)
GET  /api/scorers/:leagueCode           — Top scorers
GET  /api/live                          — All live matches right now
POST /api/refresh/live                  — Force refresh live scores
POST /api/refresh/standings?league=PL   — Force refresh standings
POST /api/refresh/all                   — Refresh everything
```

---

## 🏗️ Architecture

```
scorepulse/
├── backend/
│   ├── server.js      ← Express API server + cron jobs
│   ├── db.js          ← SQLite database layer (sql.js)
│   ├── fetcher.js     ← External API integration + mock data
│   ├── .env.example   ← API key template
│   └── scorepulse.db  ← SQLite database (auto-created)
├── public/
│   └── index.html     ← Full frontend (fetches from /api/*)
└── package.json
```

---

## 🔑 Free API Limits

| API | Free Tier | Used For |
|---|---|---|
| football-data.org | 10 req/min, 12 competitions | Standings, fixtures |
| API-Football (RapidAPI) | 100 req/day | Live scores, top scorers |

The app caches aggressively to stay within free tier limits.
