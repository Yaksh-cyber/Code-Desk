/**
 * fetcher.js — Fetches live data from external APIs and writes to DB
 *
 * Primary:   football-data.org  (free, standings + fixtures, top 12 leagues)
 * Secondary: API-Football/RapidAPI (live scores, events, top scorers)
 *
 * GET YOUR FREE API KEYS:
 *   1. football-data.org  → https://www.football-data.org/client/register
 *   2. API-Football       → https://rapidapi.com/api-sports/api/api-football (free 100/day)
 */

require('dotenv').config();
const fetch = require('node-fetch');
const { query, run, isCacheValid, updateCacheMeta, saveDb } = require('./db');

const FD_TOKEN     = process.env.FOOTBALL_DATA_TOKEN || '';
const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY || '';
const SEASON       = 2024;

// ── League ID maps ──────────────────────────────────────────────
// football-data.org code → API-Football league id
const LEAGUE_MAP = {
  PL:  { fdCode: 'PL',  apifId: 39,  name: 'Premier League',   country: 'England'  },
  CL:  { fdCode: 'CL',  apifId: 2,   name: 'Champions League', country: 'UEFA'     },
  PD:  { fdCode: 'PD',  apifId: 140, name: 'La Liga',          country: 'Spain'    },
  BL1: { fdCode: 'BL1', apifId: 78,  name: 'Bundesliga',       country: 'Germany'  },
  SA:  { fdCode: 'SA',  apifId: 135, name: 'Serie A',          country: 'Italy'    },
  FL1: { fdCode: 'FL1', apifId: 61,  name: 'Ligue 1',          country: 'France'   },
};

// ── Helpers ────────────────────────────────────────────────────
function fdHeaders() {
  return { 'X-Auth-Token': FD_TOKEN };
}

function apifHeaders() {
  return {
    'X-RapidAPI-Key': RAPIDAPI_KEY,
    'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
  };
}

async function safeFetch(url, headers, label) {
  try {
    const res = await fetch(url, { headers });
    if (!res.ok) {
      console.warn(`⚠️  [${label}] HTTP ${res.status}: ${url}`);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.error(`❌ [${label}] fetch error: ${err.message}`);
    return null;
  }
}

// ── STANDINGS via football-data.org ────────────────────────────
async function fetchStandings(leagueCode) {
  const cacheKey = `standings_${leagueCode}`;
  const ttl = parseInt(process.env.CACHE_STANDINGS_TTL) || 300;

  if (isCacheValid(cacheKey, ttl)) {
    console.log(`📋 [standings] cache hit: ${leagueCode}`);
    return;
  }

  if (!FD_TOKEN || FD_TOKEN === 'YOUR_FOOTBALL_DATA_TOKEN_HERE') {
    console.log(`🔑 [standings] No football-data.org token — using mock data`);
    seedMockStandings(leagueCode);
    return;
  }

  const url = `https://api.football-data.org/v4/competitions/${leagueCode}/standings?season=${SEASON}`;
  const data = await safeFetch(url, fdHeaders(), 'football-data standings');
  if (!data || !data.standings) return;

  // Total standing table (index 0)
  const table = data.standings.find(s => s.type === 'TOTAL');
  if (!table) return;

  // Delete old standings for this league
  run(`DELETE FROM standings WHERE league_id = ?`, [leagueCode]);

  const stmt_insert = `
    INSERT OR REPLACE INTO standings
    (id, league_id, season, position, team_id, team_name, team_logo,
     played, won, drawn, lost, goals_for, goals_against, goal_diff, points, form, description, updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `;

  table.table.forEach(row => {
    const team = row.team;
    run(stmt_insert, [
      `${leagueCode}_${team.id}`,
      leagueCode,
      SEASON,
      row.position,
      String(team.id),
      team.name,
      team.crest || '',
      row.playedGames,
      row.won,
      row.draw,
      row.lost,
      row.goalsFor,
      row.goalsAgainst,
      row.goalDifference,
      row.points,
      row.form || '',
      row.description || '',
      Math.floor(Date.now() / 1000)
    ]);
  });

  updateCacheMeta(cacheKey, ttl);
  console.log(`✅ [standings] Updated ${leagueCode}: ${table.table.length} teams`);
}

// ── FIXTURES via football-data.org ─────────────────────────────
async function fetchFixtures(leagueCode) {
  const cacheKey = `fixtures_${leagueCode}`;
  const ttl = parseInt(process.env.CACHE_FIXTURES_TTL) || 120;

  if (isCacheValid(cacheKey, ttl)) {
    console.log(`📋 [fixtures] cache hit: ${leagueCode}`);
    return;
  }

  if (!FD_TOKEN || FD_TOKEN === 'YOUR_FOOTBALL_DATA_TOKEN_HERE') {
    console.log(`🔑 [fixtures] No football-data.org token — using mock data`);
    seedMockMatches();
    return;
  }

  // Fetch today ± 3 days
  const from = new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0];
  const to   = new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0];

  const url = `https://api.football-data.org/v4/competitions/${leagueCode}/matches?dateFrom=${from}&dateTo=${to}&season=${SEASON}`;
  const data = await safeFetch(url, fdHeaders(), 'football-data fixtures');
  if (!data || !data.matches) return;

  data.matches.forEach(m => upsertMatch(m, leagueCode));
  updateCacheMeta(cacheKey, ttl);
  console.log(`✅ [fixtures] Updated ${leagueCode}: ${data.matches.length} matches`);
}

function upsertMatch(m, leagueCode) {
  const status = mapStatus(m.status);
  const home = m.homeTeam;
  const away = m.awayTeam;
  const scores = m.score;
  const homeScore = scores?.fullTime?.home ?? scores?.regularTime?.home ?? null;
  const awayScore = scores?.fullTime?.away ?? scores?.regularTime?.away ?? null;
  let winner = null;
  if (scores?.winner === 'HOME_TEAM') winner = 'home';
  else if (scores?.winner === 'AWAY_TEAM') winner = 'away';

  // Preserve existing events/stats if we have them
  const existing = query('SELECT events_json, stats_json FROM matches WHERE id = ?', [String(m.id)]);
  const eventsJson = existing.length ? existing[0].events_json : '[]';
  const statsJson  = existing.length ? existing[0].stats_json  : '{}';

  run(`
    INSERT OR REPLACE INTO matches
    (id, league_id, league_name, status, minute, match_date,
     home_team_id, home_team_name, home_team_logo, home_score,
     away_team_id, away_team_name, away_team_logo, away_score,
     winner, round, events_json, stats_json, updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `, [
    String(m.id),
    leagueCode,
    LEAGUE_MAP[leagueCode]?.name || leagueCode,
    status,
    m.minute || (status === 'live' ? '0' : ''),
    m.utcDate,
    String(home.id || ''),
    home.name || home.shortName || '',
    home.crest || '',
    homeScore,
    String(away.id || ''),
    away.name || away.shortName || '',
    away.crest || '',
    awayScore,
    winner,
    m.matchday ? `Round ${m.matchday}` : '',
    eventsJson,
    statsJson,
    Math.floor(Date.now() / 1000)
  ]);
}

function mapStatus(s) {
  if (!s) return 'scheduled';
  s = s.toUpperCase();
  if (s === 'IN_PLAY' || s === 'PAUSED') return 'live';
  if (s === 'FINISHED') return 'finished';
  return 'scheduled';
}

// ── LIVE SCORES via API-Football ───────────────────────────────
async function fetchLiveScores() {
  const cacheKey = 'live_all';
  const ttl = parseInt(process.env.CACHE_LIVE_TTL) || 30;

  if (isCacheValid(cacheKey, ttl)) return;

  if (!RAPIDAPI_KEY || RAPIDAPI_KEY === 'YOUR_RAPIDAPI_KEY_HERE') {
    console.log(`🔑 [live] No RapidAPI key — using football-data.org live data`);
    // Fall back to football-data.org live
    for (const code of Object.keys(LEAGUE_MAP)) {
      await fetchFDLive(code);
    }
    updateCacheMeta(cacheKey, ttl);
    return;
  }

  const url = 'https://api-football-v1.p.rapidapi.com/v3/fixtures?live=all';
  const data = await safeFetch(url, apifHeaders(), 'api-football live');
  if (!data || !data.response) return;

  data.response.forEach(fixture => {
    const f = fixture.fixture;
    const league = fixture.league;
    const teams = fixture.teams;
    const goals = fixture.goals;
    const events = fixture.events || [];

    // Match to our league IDs
    const leagueEntry = Object.entries(LEAGUE_MAP).find(([, v]) => v.apifId === league.id);
    if (!leagueEntry) return;
    const leagueCode = leagueEntry[0];

    const mappedEvents = events.map(e => ({
      time: e.time?.elapsed || 0,
      type: mapEventType(e.type, e.detail),
      player: e.player?.name || '',
      team: e.team?.name || '',
      side: e.team?.id === teams.home?.id ? 'home' : 'away'
    }));

    run(`
      INSERT OR REPLACE INTO matches
      (id, league_id, league_name, status, minute, match_date,
       home_team_id, home_team_name, home_team_logo, home_score,
       away_team_id, away_team_name, away_team_logo, away_score,
       winner, round, events_json, stats_json, updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `, [
      String(f.id),
      leagueCode,
      league.name,
      'live',
      String(f.status?.elapsed || ''),
      f.date,
      String(teams.home?.id || ''),
      teams.home?.name || '',
      teams.home?.logo || '',
      goals.home,
      String(teams.away?.id || ''),
      teams.away?.name || '',
      teams.away?.logo || '',
      goals.away,
      null,
      `Round ${league.round || ''}`,
      JSON.stringify(mappedEvents),
      '{}',
      Math.floor(Date.now() / 1000)
    ]);
  });

  updateCacheMeta(cacheKey, ttl);
  console.log(`✅ [live] Updated ${data.response.length} live matches`);
}

// Fallback: live from football-data.org
async function fetchFDLive(leagueCode) {
  if (!FD_TOKEN || FD_TOKEN === 'YOUR_FOOTBALL_DATA_TOKEN_HERE') return;
  const url = `https://api.football-data.org/v4/competitions/${leagueCode}/matches?status=IN_PLAY`;
  const data = await safeFetch(url, fdHeaders(), 'fd-live');
  if (!data || !data.matches) return;
  data.matches.forEach(m => upsertMatch(m, leagueCode));
}

// ── TOP SCORERS via API-Football ───────────────────────────────
async function fetchTopScorers(leagueCode) {
  const cacheKey = `scorers_${leagueCode}`;
  const ttl = 3600; // 1 hour

  if (isCacheValid(cacheKey, ttl)) return;

  const apifId = LEAGUE_MAP[leagueCode]?.apifId;
  if (!apifId) return;

  if (!RAPIDAPI_KEY || RAPIDAPI_KEY === 'YOUR_RAPIDAPI_KEY_HERE') {
    if (!FD_TOKEN || FD_TOKEN === 'YOUR_FOOTBALL_DATA_TOKEN_HERE') {
      seedMockScorers(leagueCode);
      return;
    }
    // football-data.org scorers endpoint
    const url = `https://api.football-data.org/v4/competitions/${leagueCode}/scorers?season=${SEASON}&limit=10`;
    const data = await safeFetch(url, fdHeaders(), 'fd-scorers');
    if (!data || !data.scorers) return;

    run(`DELETE FROM top_scorers WHERE league_id = ?`, [leagueCode]);
    data.scorers.forEach((s, i) => {
      run(`INSERT OR REPLACE INTO top_scorers
           (id, league_id, season, rank, player_name, team_name, nationality, goals, assists, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?)`, [
        `${leagueCode}_${s.player.id}`,
        leagueCode, SEASON, i + 1,
        s.player.name, s.team?.name || '', s.player.nationality || '',
        s.goals || 0, s.assists || 0,
        Math.floor(Date.now() / 1000)
      ]);
    });
    updateCacheMeta(cacheKey, ttl);
    return;
  }

  const url = `https://api-football-v1.p.rapidapi.com/v3/players/topscorers?league=${apifId}&season=${SEASON}`;
  const data = await safeFetch(url, apifHeaders(), 'api-football scorers');
  if (!data || !data.response) return;

  run(`DELETE FROM top_scorers WHERE league_id = ?`, [leagueCode]);
  data.response.slice(0, 10).forEach((entry, i) => {
    const p = entry.player;
    const s = entry.statistics?.[0];
    run(`INSERT OR REPLACE INTO top_scorers
         (id, league_id, season, rank, player_name, team_name, nationality, goals, assists, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?)`, [
      `${leagueCode}_${p.id}`,
      leagueCode, SEASON, i + 1,
      p.name, s?.team?.name || '', p.nationality || '',
      s?.goals?.total || 0,
      s?.goals?.assists || 0,
      Math.floor(Date.now() / 1000)
    ]);
  });

  updateCacheMeta(cacheKey, ttl);
  console.log(`✅ [scorers] Updated ${leagueCode}`);
}

function mapEventType(type, detail) {
  if (!type) return 'other';
  type = type.toLowerCase();
  if (type === 'goal') return detail?.includes('Own') ? 'own_goal' : 'goal';
  if (type === 'card') return detail?.includes('Yellow') ? 'yellow' : 'red';
  if (type === 'subst') return 'sub';
  return 'other';
}

// ── MOCK DATA (used when no API keys configured) ───────────────
function seedMockStandings(leagueCode) {
  if (leagueCode !== 'PL') return;
  const rows = [
    [1,'Liverpool','❤️', 30,22,5,3,75,30,45,71,'W,W,W,D,W',''],
    [2,'Arsenal','🔴',    30,21,4,5,70,32,38,67,'W,W,D,W,W',''],
    [3,'Man City','🩵',   30,19,5,6,68,38,30,62,'W,L,W,W,D',''],
    [4,'Tottenham','⚪',  30,18,5,7,61,43,18,59,'L,W,W,D,L','Champions League'],
    [5,'Chelsea','🔵',    30,16,5,9,55,43,12,53,'W,D,W,L,W','Europa League'],
    [6,'Aston Villa','🟣',30,15,5,10,50,40,10,50,'W,W,D,W,W','Europa League'],
    [7,'Man United','🔴', 30,13,5,12,44,51,-7,44,'L,L,W,D,L',''],
    [8,'Newcastle','⚫',  30,12,6,12,48,47,1,42,'W,D,L,W,D',''],
    [18,'Everton','🔵',   30,6,6,18,24,59,-35,24,'L,L,D,L,L','Relegation'],
    [19,'Sheffield U','🔴',30,4,4,22,18,70,-52,16,'L,L,L,D,L','Relegation'],
    [20,'Luton','🔵',     30,4,3,23,16,72,-56,15,'L,L,L,L,D','Relegation'],
  ];

  run(`DELETE FROM standings WHERE league_id = ?`, [leagueCode]);
  rows.forEach(r => {
    run(`INSERT OR REPLACE INTO standings
         (id,league_id,season,position,team_id,team_name,team_logo,played,won,drawn,lost,goals_for,goals_against,goal_diff,points,form,description,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [`${leagueCode}_${r[1]}`, leagueCode, SEASON, r[0], r[1], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], Math.floor(Date.now()/1000)]
    );
  });
}

function seedMockMatches() {
  const matches = [
    { id:'m001', league:'PL', home:'Arsenal', homeLogo:'🔴', away:'Chelsea', awayLogo:'🔵', hs:2, as_:1, status:'live', min:'67', round:'Round 30', winner:'home',
      events:[{time:14,type:'goal',player:'Saka',team:'Arsenal',side:'home'},{time:31,type:'goal',player:'Palmer',team:'Chelsea',side:'away'},{time:55,type:'goal',player:'Havertz',team:'Arsenal',side:'home'}],
      stats:{possession:[60,40],shots:[14,8],shotsOnTarget:[6,3],corners:[7,4],fouls:[9,13]} },
    { id:'m002', league:'PL', home:'Liverpool', homeLogo:'❤️', away:'Man City', awayLogo:'🩵', hs:1, as_:1, status:'live', min:'38', round:'Round 30', winner:null,
      events:[{time:22,type:'goal',player:'Salah',team:'Liverpool',side:'home'},{time:35,type:'goal',player:'Haaland',team:'Man City',side:'away'}],
      stats:{possession:[45,55],shots:[9,12],shotsOnTarget:[4,5],corners:[3,6],fouls:[11,8]} },
    { id:'m003', league:'PL', home:'Tottenham', homeLogo:'⚪', away:'Aston Villa', awayLogo:'🟣', hs:0, as_:2, status:'finished', min:'FT', round:'Round 30', winner:'away',
      events:[{time:41,type:'goal',player:'Watkins',team:'Aston Villa',side:'away'},{time:78,type:'goal',player:'Tielemans',team:'Aston Villa',side:'away'}],
      stats:{possession:[53,47],shots:[11,9],shotsOnTarget:[2,5],corners:[6,3],fouls:[14,10]} },
    { id:'m004', league:'CL', home:'Real Madrid', homeLogo:'⚪', away:'Bayern Munich', awayLogo:'🔴', hs:3, as_:2, status:'live', min:'52', round:'Quarter-Final', winner:'home',
      events:[{time:8,type:'goal',player:'Vinicius Jr',team:'Real Madrid',side:'home'},{time:23,type:'goal',player:'Kane',team:'Bayern',side:'away'},{time:39,type:'goal',player:'Bellingham',team:'Real Madrid',side:'home'},{time:45,type:'goal',player:'Müller',team:'Bayern',side:'away'},{time:51,type:'goal',player:'Mbappé',team:'Real Madrid',side:'home'}],
      stats:{possession:[48,52],shots:[16,13],shotsOnTarget:[8,6],corners:[5,7],fouls:[8,12]} },
    { id:'m005', league:'CL', home:'PSG', homeLogo:'🔵', away:'Inter Milan', awayLogo:'⚫', hs:null, as_:null, status:'scheduled', min:'21:00', round:'Quarter-Final', winner:null, events:[], stats:{} },
    { id:'m006', league:'PD', home:'Barcelona', homeLogo:'🔵', away:'Atletico Madrid', awayLogo:'🔴', hs:1, as_:0, status:'live', min:'73', round:'Round 30', winner:'home',
      events:[{time:66,type:'goal',player:'Raphinha',team:'Barcelona',side:'home'}],
      stats:{possession:[62,38],shots:[13,7],shotsOnTarget:[5,2],corners:[9,2],fouls:[7,16]} },
    { id:'m007', league:'BL1', home:'Dortmund', homeLogo:'🟡', away:'Leverkusen', awayLogo:'🔴', hs:2, as_:2, status:'finished', min:'FT', round:'Round 27', winner:null,
      events:[{time:15,type:'goal',player:'Adeyemi',team:'Dortmund',side:'home'},{time:34,type:'goal',player:'Wirtz',team:'Leverkusen',side:'away'},{time:68,type:'goal',player:'Füllkrug',team:'Dortmund',side:'home'},{time:85,type:'goal',player:'Boniface',team:'Leverkusen',side:'away'}],
      stats:{possession:[44,56],shots:[10,15],shotsOnTarget:[4,6],corners:[4,8],fouls:[12,9]} },
    { id:'m008', league:'SA', home:'Juventus', homeLogo:'⚪', away:'AC Milan', awayLogo:'🔴', hs:null, as_:null, status:'scheduled', min:'20:45', round:'Round 28', winner:null, events:[], stats:{} },
    { id:'m009', league:'PL', home:'Newcastle', homeLogo:'⚫', away:'Everton', awayLogo:'🔵', hs:null, as_:null, status:'scheduled', min:'17:30', round:'Round 30', winner:null, events:[], stats:{} },
    { id:'m010', league:'FL1', home:'Marseille', homeLogo:'🔵', away:'Monaco', awayLogo:'🔴', hs:3, as_:1, status:'finished', min:'FT', round:'Round 28', winner:'home',
      events:[{time:12,type:'goal',player:'Aubameyang',team:'Marseille',side:'home'},{time:29,type:'goal',player:'Ben Yedder',team:'Monaco',side:'away'},{time:54,type:'goal',player:'Harit',team:'Marseille',side:'home'},{time:88,type:'goal',player:'Mbemba',team:'Marseille',side:'home'}],
      stats:{possession:[55,45],shots:[17,9],shotsOnTarget:[7,3],corners:[8,3],fouls:[10,11]} },
  ];

  const leagueNames = { PL:'Premier League', CL:'Champions League', PD:'La Liga', BL1:'Bundesliga', SA:'Serie A', FL1:'Ligue 1' };

  matches.forEach(m => {
    run(`INSERT OR REPLACE INTO matches
         (id,league_id,league_name,status,minute,match_date,home_team_id,home_team_name,home_team_logo,home_score,away_team_id,away_team_name,away_team_logo,away_score,winner,round,events_json,stats_json,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [m.id, m.league, leagueNames[m.league], m.status, m.min, new Date().toISOString(),
       m.home+'_id', m.home, m.homeLogo, m.hs,
       m.away+'_id', m.away, m.awayLogo, m.as_,
       m.winner, m.round,
       JSON.stringify(m.events), JSON.stringify(m.stats),
       Math.floor(Date.now()/1000)]
    );
  });
}

function seedMockScorers(leagueCode) {
  if (leagueCode !== 'PL') return;
  const scorers = [
    [1,'Erling Haaland','Man City','Norwegian',23,8],
    [2,'Mohamed Salah','Liverpool','Egyptian',20,12],
    [3,'Cole Palmer','Chelsea','English',18,9],
    [4,'Alexander Isak','Newcastle','Swedish',17,4],
    [5,'Bukayo Saka','Arsenal','English',16,13],
    [6,'Son Heung-min','Tottenham','South Korean',15,8],
    [7,'Dominic Solanke','Tottenham','English',14,3],
    [8,'Ollie Watkins','Aston Villa','English',13,11],
    [9,'Jamie Vardy','Leicester','English',12,2],
    [10,'Marcus Rashford','Man United','English',11,5],
  ];

  run(`DELETE FROM top_scorers WHERE league_id = ?`, [leagueCode]);
  scorers.forEach(s => {
    run(`INSERT OR REPLACE INTO top_scorers (id,league_id,season,rank,player_name,team_name,nationality,goals,assists,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [`${leagueCode}_${s[1].replace(/\s/g,'_')}`, leagueCode, SEASON, s[0], s[1], s[2], s[3], s[4], s[5], Math.floor(Date.now()/1000)]
    );
  });
}

// ── BOOTSTRAP: seed all mock data on startup ───────────────────
async function bootstrap() {
  console.log('🚀 Bootstrapping data...');
  seedMockMatches();

  for (const code of Object.keys(LEAGUE_MAP)) {
    seedMockStandings(code);
    seedMockScorers(code);
  }

  // Try to fetch real data if tokens present
  if (FD_TOKEN && FD_TOKEN !== 'YOUR_FOOTBALL_DATA_TOKEN_HERE') {
    for (const code of Object.keys(LEAGUE_MAP)) {
      await fetchStandings(code);
      await fetchFixtures(code);
      await new Promise(r => setTimeout(r, 700)); // rate limit
    }
  }

  if (RAPIDAPI_KEY && RAPIDAPI_KEY !== 'YOUR_RAPIDAPI_KEY_HERE') {
    await fetchLiveScores();
    await fetchTopScorers('PL');
  }

  console.log('✅ Bootstrap complete');
}

// ── MAIN EXPORT ────────────────────────────────────────────────
module.exports = {
  bootstrap,
  fetchStandings,
  fetchFixtures,
  fetchLiveScores,
  fetchTopScorers,
  LEAGUE_MAP
};
