/**
 * db.js — SQLite via sql.js (pure JS, no native bindings needed)
 * Stores: leagues, teams, matches, standings, scorers, cache metadata
 */

const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'scorepulse.db');

let db = null;

async function getDb() {
  if (db) return db;

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  initSchema();
  return db;
}

function saveDb() {
  if (!db) return;
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function initSchema() {
  db.run(`
    CREATE TABLE IF NOT EXISTS leagues (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      country TEXT,
      flag TEXT,
      external_id TEXT,
      season INTEGER,
      logo_url TEXT,
      updated_at INTEGER DEFAULT 0
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS teams (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      short_name TEXT,
      logo TEXT,
      logo_url TEXT,
      league_id TEXT,
      FOREIGN KEY(league_id) REFERENCES leagues(id)
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS matches (
      id TEXT PRIMARY KEY,
      league_id TEXT,
      league_name TEXT,
      status TEXT,
      minute TEXT,
      match_date TEXT,
      home_team_id TEXT,
      home_team_name TEXT,
      home_team_logo TEXT,
      home_score INTEGER,
      away_team_id TEXT,
      away_team_name TEXT,
      away_team_logo TEXT,
      away_score INTEGER,
      winner TEXT,
      venue TEXT,
      round TEXT,
      events_json TEXT DEFAULT '[]',
      stats_json TEXT DEFAULT '{}',
      updated_at INTEGER DEFAULT 0,
      FOREIGN KEY(league_id) REFERENCES leagues(id)
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS standings (
      id TEXT PRIMARY KEY,
      league_id TEXT,
      season INTEGER,
      position INTEGER,
      team_id TEXT,
      team_name TEXT,
      team_logo TEXT,
      played INTEGER DEFAULT 0,
      won INTEGER DEFAULT 0,
      drawn INTEGER DEFAULT 0,
      lost INTEGER DEFAULT 0,
      goals_for INTEGER DEFAULT 0,
      goals_against INTEGER DEFAULT 0,
      goal_diff INTEGER DEFAULT 0,
      points INTEGER DEFAULT 0,
      form TEXT,
      description TEXT,
      updated_at INTEGER DEFAULT 0,
      FOREIGN KEY(league_id) REFERENCES leagues(id)
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS top_scorers (
      id TEXT PRIMARY KEY,
      league_id TEXT,
      season INTEGER,
      rank INTEGER,
      player_name TEXT,
      team_name TEXT,
      nationality TEXT,
      goals INTEGER DEFAULT 0,
      assists INTEGER DEFAULT 0,
      updated_at INTEGER DEFAULT 0
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS cache_meta (
      key TEXT PRIMARY KEY,
      fetched_at INTEGER,
      ttl INTEGER
    );
  `);

  // Seed default leagues
  const leagues = [
    { id: 'PL',  name: 'Premier League',    country: 'England',     flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿', external_id: 'PL',  season: 2024, api_football_id: 39 },
    { id: 'CL',  name: 'Champions League',  country: 'UEFA',        flag: '🇪🇺', external_id: 'CL',  season: 2024, api_football_id: 2  },
    { id: 'PD',  name: 'La Liga',           country: 'Spain',       flag: '🇪🇸', external_id: 'PD',  season: 2024, api_football_id: 140 },
    { id: 'BL1', name: 'Bundesliga',        country: 'Germany',     flag: '🇩🇪', external_id: 'BL1', season: 2024, api_football_id: 78 },
    { id: 'SA',  name: 'Serie A',           country: 'Italy',       flag: '🇮🇹', external_id: 'SA',  season: 2024, api_football_id: 135 },
    { id: 'FL1', name: 'Ligue 1',           country: 'France',      flag: '🇫🇷', external_id: 'FL1', season: 2024, api_football_id: 61 },
  ];

  const stmt = db.prepare(`
    INSERT OR IGNORE INTO leagues (id, name, country, flag, external_id, season)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  leagues.forEach(l => stmt.run([l.id, l.name, l.country, l.flag, l.external_id, l.season]));
  stmt.free();

  saveDb();
  console.log('📦 Database schema initialized');
}

// Generic query helpers
function query(sql, params = []) {
  if (!db) throw new Error('DB not initialized');
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

function run(sql, params = []) {
  if (!db) throw new Error('DB not initialized');
  db.run(sql, params);
  saveDb();
}

function isCacheValid(key, ttl) {
  const rows = query('SELECT fetched_at, ttl FROM cache_meta WHERE key = ?', [key]);
  if (!rows.length) return false;
  const age = (Date.now() / 1000) - rows[0].fetched_at;
  return age < (ttl || rows[0].ttl);
}

function updateCacheMeta(key, ttl) {
  run(`INSERT OR REPLACE INTO cache_meta (key, fetched_at, ttl) VALUES (?, ?, ?)`,
    [key, Math.floor(Date.now() / 1000), ttl]);
}

module.exports = { getDb, saveDb, query, run, isCacheValid, updateCacheMeta };
